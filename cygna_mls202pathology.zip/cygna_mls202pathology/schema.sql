-- ============================================================================
-- © cygna.co - cygna.consult | Cygna MLS202 Pathology Quiz (cygna_mls202pathology)
-- Run this ONCE in: Supabase Dashboard > SQL Editor > New query > paste > RUN
-- Safe for the SAME Supabase project that already has these tables (App 6):
--   * CREATE TABLE IF NOT EXISTS  -> will not touch existing tables/data
--   * ADD COLUMN IF NOT EXISTS    -> only adds missing columns
--   * DROP POLICY IF EXISTS       -> then re-creates this app's policies
-- ============================================================================

-- ---------- 1. TABLES ----------
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  email       text,
  role        text default 'student',
  app_name    text,
  created_at  timestamptz default now()
);
alter table public.profiles add column if not exists full_name  text;
alter table public.profiles add column if not exists email      text;
alter table public.profiles add column if not exists role       text default 'student';
alter table public.profiles add column if not exists app_name   text;
alter table public.profiles add column if not exists created_at timestamptz default now();

create table if not exists public.results (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid references auth.users(id) on delete cascade,
  full_name        text,
  email            text,
  app_name         text,
  topics           text,
  mode             text,
  score            integer,
  total_questions  integer,
  percentage       numeric,
  grade            text,
  pass_fail        text,
  time_used        integer,
  topic_stats      jsonb,
  created_at       timestamptz default now()
);
alter table public.results add column if not exists user_id         uuid;
alter table public.results add column if not exists full_name       text;
alter table public.results add column if not exists email           text;
alter table public.results add column if not exists app_name        text;
alter table public.results add column if not exists topics          text;
alter table public.results add column if not exists mode            text;
alter table public.results add column if not exists score           integer;
alter table public.results add column if not exists total_questions integer;
alter table public.results add column if not exists percentage      numeric;
alter table public.results add column if not exists grade           text;
alter table public.results add column if not exists pass_fail       text;
alter table public.results add column if not exists time_used       integer;
alter table public.results add column if not exists topic_stats     jsonb;
alter table public.results add column if not exists created_at      timestamptz default now();

create index if not exists cygna_mls202_results_app_idx  on public.results (app_name, created_at desc);
create index if not exists cygna_mls202_results_user_idx on public.results (user_id);
create index if not exists cygna_mls202_profiles_app_idx on public.profiles (app_name);

-- ---------- 2. ADMIN CHECK (hardcoded admin email, verified from the login token) ----------
create or replace function public.cygna_mls202_is_admin()
returns boolean
language sql
stable
as $$
  select lower(coalesce(auth.jwt() ->> 'email', '')) = lower('olamgeorg9@gmail.com');
$$;

-- ---------- 3. ROW LEVEL SECURITY ----------
alter table public.profiles enable row level security;
alter table public.results  enable row level security;

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.profiles to authenticated;
grant select, insert, update, delete on public.results  to authenticated;

-- profiles
drop policy if exists "cygna_mls202_profiles_select" on public.profiles;
create policy "cygna_mls202_profiles_select" on public.profiles
  for select to authenticated
  using (auth.uid() = id or public.cygna_mls202_is_admin());

drop policy if exists "cygna_mls202_profiles_insert" on public.profiles;
create policy "cygna_mls202_profiles_insert" on public.profiles
  for insert to authenticated
  with check (auth.uid() = id);

drop policy if exists "cygna_mls202_profiles_update" on public.profiles;
create policy "cygna_mls202_profiles_update" on public.profiles
  for update to authenticated
  using (auth.uid() = id or public.cygna_mls202_is_admin())
  with check (auth.uid() = id or public.cygna_mls202_is_admin());

drop policy if exists "cygna_mls202_profiles_delete_admin" on public.profiles;
create policy "cygna_mls202_profiles_delete_admin" on public.profiles
  for delete to authenticated
  using (public.cygna_mls202_is_admin());

-- results
drop policy if exists "cygna_mls202_results_select" on public.results;
create policy "cygna_mls202_results_select" on public.results
  for select to authenticated
  using (auth.uid() = user_id or public.cygna_mls202_is_admin());

drop policy if exists "cygna_mls202_results_insert" on public.results;
create policy "cygna_mls202_results_insert" on public.results
  for insert to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "cygna_mls202_results_delete_admin" on public.results;
create policy "cygna_mls202_results_delete_admin" on public.results
  for delete to authenticated
  using (public.cygna_mls202_is_admin());

-- ---------- 4. AUTO-CREATE PROFILE ON SIGN-UP (works even when email confirmation is ON) ----------
create or replace function public.cygna_mls202_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, role, app_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)),
    lower(new.email),
    case when lower(new.email) = lower('olamgeorg9@gmail.com') then 'admin' else 'student' end,
    coalesce(new.raw_user_meta_data ->> 'app_name', 'cygna_mls202pathology')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists cygna_mls202_on_auth_user_created on auth.users;
create trigger cygna_mls202_on_auth_user_created
  after insert on auth.users
  for each row execute function public.cygna_mls202_handle_new_user();

-- DONE. Now sign up in the app with olamgeorg9@gmail.com to create your admin account.
